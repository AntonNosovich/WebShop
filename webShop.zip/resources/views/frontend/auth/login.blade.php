@extends('layouts.layout')
@section('content')
<form method="POST" action=  "{{route('postLogin')}}">
@csrf <!-- {{ csrf_field() }} -->
    <div style="margin: 10px">
        <span>Email</span>
        <input name="email" type="email" >

    </div>
    @error('email')

    <p class="text-red-500">{{$message}}</p>
    @enderror
    <div style="margin: 10px">
        <span>Password</span>
        <input name="password" type="password">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" name="remember_me">
            <label class="form-check-label" for="flexCheckChecked">
                Remember me
            </label>
        </div>
    </div>
    <button type="submit"  class="btn-primary btn" >Send</button>
    <div>
        <a href="{{route('register')}}">Create account</a>
    </div>
</form>
@endsection
