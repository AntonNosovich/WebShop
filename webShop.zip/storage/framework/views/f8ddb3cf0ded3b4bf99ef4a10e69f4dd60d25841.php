<?php $__env->startSection('content'); ?>
<form method="POST" action=  "<?php echo e(route('postLogin')); ?>">
<?php echo csrf_field(); ?> <!-- <?php echo e(csrf_field()); ?> -->
    <div style="margin: 10px">
        <span>Email</span>
        <input name="email" type="email" >

    </div>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

    <p class="text-red-500"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div style="margin: 10px">
        <span>Password</span>
        <input name="password" type="password">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked" name="remember_me">
            <label class="form-check-label" for="flexCheckChecked">
                Remember me
            </label>
        </div>
    </div>
    <button type="submit"  class="btn-primary btn" >Send</button>
    <div>
        <a href="<?php echo e(route('register')); ?>">Create account</a>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/frontend/auth/login.blade.php ENDPATH**/ ?>