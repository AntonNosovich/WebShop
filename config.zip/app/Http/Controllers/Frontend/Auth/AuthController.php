<?php

namespace App\Http\Controllers\Frontend\Auth;


use App\Http\Controllers\Frontend\Requests\RegisterRequest;
use App\Http\Controllers\Frontend\Requests\LoginRequest;
use App\Models\User;
//use Illuminate\Http\Request;//Откатил назад

use Illuminate\Support\Facades\Auth;

class AuthController
{
    public function login()
    {
//        if(Auth::check()){
//            return redirect(route('user.private'));
//        }
        return view('frontend.auth.login');
    }

    public function register()
    {
//        if(Auth::check()){
//            return redirect(route('user.private'));
//        }
        return view('frontend.auth.register');
    }

    public function home(){
        return view('frontend.auth.auntificate');
    }

    public function postLogin(LoginRequest $request){
        $formFields = $request->only(['email','password']);
        $remember = $request->input(['remember_me']);

        if (Auth::attempt($formFields,$remember)){
            return redirect()->intended('home');
        }

        return redirect(route('login'))->withErrors([
            'email'=>'Error password or email'
        ]);


    }
    public function postLogout(){
        Auth::logout();
        return redirect('login');
    }

    public function postRegister(RegisterRequest $request)
    {

//        $user = User::query();
//        $user->name = $request->name;
//        $user->save();
        $user = User::create($request->validated());
        if ($user){
            auth('web')->login($user);
        }
        return redirect(route('home'));

    }
}

