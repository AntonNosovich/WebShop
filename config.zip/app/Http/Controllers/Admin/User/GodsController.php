<?php

namespace App\Http\Controllers\Admin\User;

class GodsController
{

}
