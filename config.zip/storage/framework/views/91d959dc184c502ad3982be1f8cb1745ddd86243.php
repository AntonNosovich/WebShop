<?php $__env->startSection('content'); ?>
<div>
    <span>You are in the system</span>
</div>
<div>
    <a href="<?php echo e(route('postLogout')); ?>">Exit</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /application/resources/views/frontend/auth/auntificate.blade.php ENDPATH**/ ?>